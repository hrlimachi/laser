#ifndef FS_h
  #include "FS.h"
#endif
#ifndef SD_h
  #include "SD.h"
#endif
#ifndef SPI_h
  #include "SPI.h"
#endif

class SD_lib{
  SD_lib(){
    
  }
};
